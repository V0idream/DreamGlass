/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: /usr/local/lib/android/sdk/build-tools/37.0.0/aidl -p/usr/local/lib/android/sdk/platforms/android-37.0/framework.aidl -o/home/runner/work/service/service/interface/build/generated/aidl_source_output_dir/release/out -I/home/runner/work/service/service/interface/src/main/aidl -I/home/runner/work/service/service/interface/src/release/aidl -d/tmp/aidl4711179541617501907.d /home/runner/work/service/service/interface/src/main/aidl/io/github/libxposed/service/IXposedScopeCallback.aidl
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package io.github.libxposed.service;
public interface IXposedScopeCallback extends android.os.IInterface
{
  /** Default implementation for IXposedScopeCallback. */
  public static class Default implements io.github.libxposed.service.IXposedScopeCallback
  {
    @Override public void onScopeRequestApproved(java.util.List<java.lang.String> approved) throws android.os.RemoteException
    {
    }
    @Override public void onScopeRequestFailed(java.lang.String message) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements io.github.libxposed.service.IXposedScopeCallback
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an io.github.libxposed.service.IXposedScopeCallback interface,
     * generating a proxy if needed.
     */
    public static io.github.libxposed.service.IXposedScopeCallback asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof io.github.libxposed.service.IXposedScopeCallback))) {
        return ((io.github.libxposed.service.IXposedScopeCallback)iin);
      }
      return new io.github.libxposed.service.IXposedScopeCallback.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(DESCRIPTOR);
      }
      switch (code)
      {
        case TRANSACTION_onScopeRequestApproved:
        {
          java.util.List<java.lang.String> _arg0;
          _arg0 = data.createStringArrayList();
          this.onScopeRequestApproved(_arg0);
          break;
        }
        case TRANSACTION_onScopeRequestFailed:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          this.onScopeRequestFailed(_arg0);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static final class Proxy implements io.github.libxposed.service.IXposedScopeCallback
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public final java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      @Override public void onScopeRequestApproved(java.util.List<java.lang.String> approved) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStringList(approved);
          boolean _status = mRemote.transact(Stub.TRANSACTION_onScopeRequestApproved, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public void onScopeRequestFailed(java.lang.String message) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(message);
          boolean _status = mRemote.transact(Stub.TRANSACTION_onScopeRequestFailed, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_onScopeRequestApproved = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
    static final int TRANSACTION_onScopeRequestFailed = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "io.github.libxposed.service.IXposedScopeCallback";
  public void onScopeRequestApproved(java.util.List<java.lang.String> approved) throws android.os.RemoteException;
  public void onScopeRequestFailed(java.lang.String message) throws android.os.RemoteException;
}
